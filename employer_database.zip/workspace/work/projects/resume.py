#! usr/bin/python

#from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from selenium import webdriver
import time




try: 
    chrome_path = "/home/ubuntu/workspace/work/projects"
    
    driver = webdriver.Chrome(chrome_path)
    
    driver.get("http://www.indeed.com/jobs?q=receptionist&l=San+Jose%2C+CA&sort=date")
    
    driver.find_element_by_xpath("""//*[@id="jl_7ba4fdbe7b09b289"]/a""").click()
    
    posts = driver.find_elements_by_class_name("turnstileLink")
    
    for post in posts:
    	print(post.text)
    	
except:
    print("Path error: Check to see if Webdriver is in SYSTEMPATH")


'''
try:
        document = Document()
        
        
        #Personal Information Header
        document.add_heading('Jeremy Cornish-Ford \n Ford.Jeremy510@gmail.com \n 408.600.9128')
        
        #Job Title 
        document.add_heading('Administrative Assitant')
        
        #Education
        document.add_heading("Education:")
        
        
        document.add_paragraph('Associate of Science in Computer Science \n De Anza College')
        
        Employers = [ "Part-Time Associate- Smart and Final Extra",
                    "Inventory Manager-World Computer Exchange",
                    "Administrative Assistant-United Neighborhood Improvement Association",
                    ]
        
        Experience = ['Stocked and organized products according to FIFO rule Trained and Mentored new students \n Helpend save the world'
                     ]
                      
        #Experience
        document.add_heading('Experience:')
        
        
        document.add_paragraph('Inventory Manager - World Computer Exchange \n' + str(Experience))
        
        #Awards
        
        document.add_heading('Awards')
        document.add_paragraph('Teamwork-Smart and Final Extra')
        document.add_paragraph('President of Leadership Program-San Jose Job Corps')
        
        
        
        
        #Save resume
        document.save('office_resume.docx')
        
except:
        print('Auto-Resume Generator failed')